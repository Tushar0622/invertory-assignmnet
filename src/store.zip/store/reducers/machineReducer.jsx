const initialState = {
    machineList: [],
    machineTypes: [],
}

export const machineReducer = (state = initialState, action) => {
    switch (action.type) {
        case "GET_MACHINE_LIST":
            return {
                ...state,
                machineList: action.payload
            }
        case "GET_MACHINE_TYPES":
            return {
                ...state,
                machineTypes: action.payload
            }
        default:
            return state;
    }
}