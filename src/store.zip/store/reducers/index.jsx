import { combineReducers } from "redux";
import { machineReducer } from "./machineReducer";
import { machineTypeReducer } from "./machineTypeReducer";

const rootReducer = combineReducers({
    machineReducer,
    machineTypeReducer
});

export default rootReducer;