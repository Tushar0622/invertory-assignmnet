export const addNewMachine = (data) => ({
    type: "ADD_NEW_MACHINE",
    payload: data
});

export const getMachineList = (data) => ({
    type: "GET_MACHINE_LIST",
    payload: data
});

export const getMachine = (data) => ({
    type: "GET_MACHINE",
    payload: data
});

